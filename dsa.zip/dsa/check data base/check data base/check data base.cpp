#include <iostream>
#include<string>
#include <windows.h>  
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>
using namespace std;

struct Patient {
    static int idCounter;
    int id;
    string name;
    int age;
    double weight;
    string gender;
    string medicalHistory;
    int priority;
    Patient* next;

    Patient(string n, int a, double w, string g, string mh, int p) : id(++idCounter), name(n), age(a), weight(w), gender(g), medicalHistory(mh), priority(p), next(nullptr) {}
};

int Patient::idCounter = 0;

struct PriorityQueue {
    Patient* front;

    PriorityQueue() {
        front = nullptr;
    }

    void enqueue(const Patient& patient) {
        Patient* newNode = new Patient(patient.name, patient.age, patient.weight, patient.gender, patient.medicalHistory, patient.priority);

        if (!front || front->priority < patient.priority) {
            newNode->next = front;
            front = newNode;
        }
        else {
            Patient* temp = front;
            while (temp->next && temp->next->priority >= patient.priority) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    Patient dequeue() {
        if (!front) {
            cerr << "Queue is empty." << endl;
            return Patient("", -1, -1.0, "", "", -1);
        }

        Patient* temp = front;
        front = front->next;
        temp->next = nullptr;

        Patient dequeuedPatient = *temp;
        delete temp;

        return dequeuedPatient;
    }

    void displayQueue() {
        Patient* temp = front;
        int order = 1;

        while (temp) {
            cout << "Order: " << order << " ID: " << temp->id << " Patient: " << temp->name << " Age: " << temp->age
                << " Weight: " << temp->weight << " Gender: " << temp->gender
                << " Medical History: " << temp->medicalHistory << " Priority: " << temp->priority << endl;

            temp = temp->next;
            order++;
        }
    }

    Patient* searchPatientById(int patientId) {
        Patient* temp = front;
        while (temp) {
            if (temp->id == patientId) {
                return temp;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    bool isEmpty() const {
        return front == nullptr;
    }

    void treatPatient() {
        if (!front) {
            cout << "No patients in the queue to treat." << endl;
            return;
        }

        Patient treatedPatient = dequeue();
        cout << "Patient treated: " << treatedPatient.name << ". Priority adjusted for remaining patients." << endl;

    }

};

void updatePatientInformation(Patient* patient) {
    cout << "Enter updated patient name: ";
    cin >> patient->name;
    cout << "Enter updated patient age: ";
    cin >> patient->age;
    cout << "Enter updated patient weight: ";
    cin >> patient->weight;
    cout << "Enter updated patient gender: ";
    cin >> patient->gender;
    cout << "Enter updated patient medical history: ";
    cin.ignore(); 
    getline(cin, patient->medicalHistory);
    cout << "Enter updated patient priority: ";
    cin >> patient->priority;
}

void removePatientById(PriorityQueue& queue, int patientId) {
    Patient* current = queue.front;
    Patient* previous = nullptr;

    while (current) {
        if (current->id == patientId) {
            if (previous) {
                previous->next = current->next;
            }
            else {
                queue.front = current->next;
            }

            delete current;
            current = previous ? previous->next : queue.front;
        }
        else {
            previous = current;
            current = current->next;
        }
    }
}

void displayStatistics(const PriorityQueue& queue) {
    int totalPatients = 0;
    int malePatients = 0;
    int femalePatients = 0;
    double averageAge = 0;
    double averageWeight = 0;
    int maxPriority = INT_MIN;
    int minPriority = INT_MAX;

    Patient* temp = queue.front;
    while (temp) {
        totalPatients++;
        averageAge += temp->age;
        averageWeight += temp->weight;
        maxPriority = max(maxPriority, temp->priority);
        minPriority = min(minPriority, temp->priority);

        if (temp->gender == "male") {
            malePatients++;
        }
        else if (temp->gender == "female") {
            femalePatients++;
        }

        temp = temp->next;
    }

    if (totalPatients > 0) {
        averageAge /= totalPatients;
        averageWeight /= totalPatients;
    }

    cout << "Total number of patients: " << totalPatients << endl;
    cout << "Number of male patients: " << malePatients << endl;
    cout << "Number of female patients: " << femalePatients << endl;
    cout << "Average age: " << averageAge << endl;
    cout << "Average weight: " << averageWeight << endl;
    cout << "Maximum priority: " << maxPriority << endl;
    cout << "Minimum priority: " << minPriority << endl;
}
void Cleanup(SQLHANDLE hStmt, SQLHANDLE hConn, SQLHANDLE hEnv) {
    // Cleanup
    if (hStmt != SQL_NULL_HANDLE) SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    if (hConn != SQL_NULL_HANDLE) {
        SQLDisconnect(hConn);
        SQLFreeHandle(SQL_HANDLE_DBC, hConn);
    }
    if (hEnv != SQL_NULL_HANDLE) SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
}

void InsertRecord(string name, int age, int weight, string gender, string medicalHistory, int priority) {
    SQLHANDLE hEnv = SQL_NULL_HANDLE;
    SQLHANDLE hConn = SQL_NULL_HANDLE;
    SQLHANDLE hStmt = SQL_NULL_HANDLE;

    try {
        // Establish a connection to the SQL Server
        SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv);
        SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0);
        SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hConn);

        // Connection string
        SQLCHAR* connString = (SQLCHAR*)"DRIVER={SQL Server};SERVER=desktop-09i68j2\\sqlexpress;DATABASE=forum2024;Integrated Security=True";

        // Connect to the SQL Server database
        SQLRETURN retcode = SQLDriverConnectA(hConn, NULL, connString, SQL_NTS, NULL, 0, NULL, SQL_DRIVER_NOPROMPT);

        if (retcode != SQL_SUCCESS && retcode != SQL_SUCCESS_WITH_INFO) {
            cerr << "Error connecting to the database" << endl;
            throw runtime_error("Database connection error");
        }

       
        SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);

        string insertQuery = "INSERT INTO hospital (name, age, weight, gender, medicalHistory, priority) VALUES (?, ?, ?, ?, ?, ?)";
        retcode = SQLPrepareA(hStmt, (SQLCHAR*)insertQuery.c_str(), SQL_NTS);

        if (retcode != SQL_SUCCESS) {
            cerr << "Error preparing SQL statement" << endl;

            
            SQLSMALLINT recNumber = 1;
            SQLCHAR sqlState[6];
            SQLINTEGER nativeError;
            SQLCHAR messageText[256];
            SQLSMALLINT textLength;

            while (SQLGetDiagRecA(SQL_HANDLE_STMT, hStmt, recNumber, sqlState, &nativeError, messageText, sizeof(messageText), &textLength) == SQL_SUCCESS) {
                cerr << "SQL State: " << sqlState << ", Native Error: " << nativeError << ", Message: " << messageText << endl;
                recNumber++;
            }

            throw runtime_error("SQL statement preparation error");
        }

        
        SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 255, 0, (SQLPOINTER)name.c_str(), 0, NULL);
        SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, (SQLPOINTER)&age, 0, NULL);
        SQLBindParameter(hStmt, 3, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, (SQLPOINTER)&weight, 0, NULL);
        SQLBindParameter(hStmt, 4, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 255, 0, (SQLPOINTER)gender.c_str(), 0, NULL);
        SQLBindParameter(hStmt, 5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 255, 0, (SQLPOINTER)medicalHistory.c_str(), 0, NULL);
        SQLBindParameter(hStmt, 6, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, (SQLPOINTER)&priority, 0, NULL);

        
        retcode = SQLExecute(hStmt);

        if (retcode != SQL_SUCCESS) {
            cerr << "Error executing SQL statement" << endl;

            
            SQLSMALLINT recNumber = 1;
            SQLCHAR sqlState[6];
            SQLINTEGER nativeError;
            SQLCHAR messageText[256];
            SQLSMALLINT textLength;

            while (SQLGetDiagRecA(SQL_HANDLE_STMT, hStmt, recNumber, sqlState, &nativeError, messageText, sizeof(messageText), &textLength) == SQL_SUCCESS) {
                cerr << "SQL State: " << sqlState << ", Native Error: " << nativeError << ", Message: " << messageText << endl;
                recNumber++;
            }

            throw runtime_error("SQL statement execution error");
        }

        cout << "Data inserted successfully!" << endl;

        Cleanup(hStmt, hConn, hEnv);
    }
    catch (const exception& e) {
        cerr << e.what() << endl;

        
        Cleanup(hStmt, hConn, hEnv);
    }
}

void FetchAllData() {
    SQLHANDLE hEnv = SQL_NULL_HANDLE;
    SQLHANDLE hConn = SQL_NULL_HANDLE;
    SQLHANDLE hStmt = SQL_NULL_HANDLE;

    try {
        
        SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv);
        SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0);
        SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hConn);

        SQLCHAR* connString = (SQLCHAR*)"DRIVER={SQL Server};SERVER=desktop-09i68j2\\sqlexpress;DATABASE=forum2024;Integrated Security=True";

        // Connect to the SQL Server database
        SQLRETURN retcode = SQLDriverConnectA(hConn, NULL, connString, SQL_NTS, NULL, 0, NULL, SQL_DRIVER_NOPROMPT);

        if (retcode != SQL_SUCCESS && retcode != SQL_SUCCESS_WITH_INFO) {
            cerr << "Error connecting to the database" << endl;
            throw runtime_error("Database connection error");
        }

  
        SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);

        string selectQuery = "SELECT name, age, weight, gender, medicalHistory, priority FROM hospital";
        retcode = SQLExecDirectA(hStmt, (SQLCHAR*)selectQuery.c_str(), SQL_NTS);

        if (retcode != SQL_SUCCESS) {
            cerr << "Error executing SQL statement" << endl;

            // Retrieve and print SQL Server error details
            SQLSMALLINT recNumber = 1;
            SQLCHAR sqlState[6];
            SQLINTEGER nativeError;
            SQLCHAR messageText[256];
            SQLSMALLINT textLength;

            while (SQLGetDiagRecA(SQL_HANDLE_STMT, hStmt, recNumber, sqlState, &nativeError, messageText, sizeof(messageText), &textLength) == SQL_SUCCESS) {
                cerr << "SQL State: " << sqlState << ", Native Error: " << nativeError << ", Message: " << messageText << endl;
                recNumber++;
            }

            throw runtime_error("SQL statement execution error");
        }

        // Fetch and print results
        SQLCHAR name[256];
        SQLINTEGER age, weight, priority;
        SQLCHAR gender[256], medicalHistory[256];

        while (SQLFetch(hStmt) == SQL_SUCCESS) {
            SQLGetData(hStmt, 1, SQL_C_CHAR, name, sizeof(name), NULL);
            SQLGetData(hStmt, 2, SQL_C_LONG, &age, 0, NULL);
            SQLGetData(hStmt, 3, SQL_C_LONG, &weight, 0, NULL);
            SQLGetData(hStmt, 4, SQL_C_CHAR, gender, sizeof(gender), NULL);
            SQLGetData(hStmt, 5, SQL_C_CHAR, medicalHistory, sizeof(medicalHistory), NULL);
            SQLGetData(hStmt, 6, SQL_C_LONG, &priority, 0, NULL);

            cout << "Name: " << name << ", Age: " << age << ", Weight: " << weight << ", Gender: " << gender
                << ", Medical History: " << medicalHistory << ", Priority: " << priority << endl;
        }

        // Cleanup
        Cleanup(hStmt, hConn, hEnv);
    }
    catch (const exception& e) {
        cerr << e.what() << endl;

        // Cleanup in case of an exception
        Cleanup(hStmt, hConn, hEnv);
    }
}
    void DeleteRecordsByName (string name)
    {
        SQLHANDLE hEnv = SQL_NULL_HANDLE;
        SQLHANDLE hConn = SQL_NULL_HANDLE;
        SQLHANDLE hStmt = SQL_NULL_HANDLE;

        try {
            // Establish a connection to the SQL Server
            SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv);
            SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0);
            SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hConn);

            // Connection string
            SQLCHAR* connString = (SQLCHAR*)"DRIVER={SQL Server};SERVER=desktop-09i68j2\\sqlexpress;DATABASE=forum2024;Integrated Security=True";

            // Connect to the SQL Server database
            SQLRETURN retcode = SQLDriverConnectA(hConn, NULL, connString, SQL_NTS, NULL, 0, NULL, SQL_DRIVER_NOPROMPT);

            if (retcode != SQL_SUCCESS && retcode != SQL_SUCCESS_WITH_INFO) {
                cerr << "Error connecting to the database" << endl;
                throw runtime_error("Database connection error");
            }

            SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);

            
            string deleteQuery = "DELETE FROM hospital WHERE name = '" + name + "'";
            retcode = SQLExecDirectA(hStmt, (SQLCHAR*)deleteQuery.c_str(), SQL_NTS);

            if (retcode != SQL_SUCCESS) {
                cerr << "Error executing SQL statement" << endl;

                SQLSMALLINT recNumber = 1;
                SQLCHAR sqlState[6];
                SQLINTEGER nativeError;
                SQLCHAR messageText[256];
                SQLSMALLINT textLength;

                while (SQLGetDiagRecA(SQL_HANDLE_STMT, hStmt, recNumber, sqlState, &nativeError, messageText, sizeof(messageText), &textLength) == SQL_SUCCESS) {
                    cerr << "SQL State: " << sqlState << ", Native Error: " << nativeError << ", Message: " << messageText << endl;
                    recNumber++;
                }

                throw runtime_error("SQL statement execution error");
            }

            cout << "Records for '" << name << "' deleted successfully!" << endl;

            // Cleanup
            Cleanup(hStmt, hConn, hEnv);
        }
        catch (const exception& e) {
            cerr << e.what() << endl;

            // Cleanup in case of an exception
            Cleanup(hStmt, hConn, hEnv);
        }
    }
bool isValidInput(const string& str) {
    return str.find_first_of("0123456789") == string::npos;
}
int main() {
    PriorityQueue queue;
    int option;
    

    do {
        cout << "Menu:\n";
        cout << "1. Add\n";
        cout << "2. Display data in today's record\n";
        cout << "3. Search\n";
        cout << "4. Update\n";
        cout << "5. Remove\n";
        cout << "6. Statistics\n";
        cout << "7. Treat Patient\n";
        cout << "8. Display all the record in the database\n";
        cout << "9. Delete the record of the client in database\n";
        cout << "10. Exit\n";
        cout << "Enter option: ";
        cin >> option;

        if (option == 1) {
            while (true) {
                string name, gender, medicalHistory;
                int age, weight, priority;

                while (true)
                {
                    string username;
                    cout << "Enter the patient name: ";
                    cin >> username;
                    if (isValidInput(username)) {
                        name = username;
                        break;
                    }
                    else {
                        cout << "Invalid input. The name contains numbers." << endl;
                    }
                }
                while (true) {
                    try {
                        int userage;
                        cout << "Enter patient age: ";
                        cin >> userage;

                        if (userage <= 0) {
                            throw runtime_error("Error: Invalid age entered. Please enter a positive integer.");
                        }

                        age = userage;
                        break;
                    }
                    catch (const exception& e) {
                        cin.clear();  // clear input buffer
                        cerr << e.what() << endl;
                    }
                }
                while (true)
                {
                    int userweight;
                    cout << "Enter patient weight: ";
                    cin >> userweight;
                    if (userweight > 0)
                    {
                        weight = userweight;
                        break;
                    }
                    else
                    {
                        cout << "Error: Invalid age entered. Please try again." << endl;
                    }
                }
                while (true) {
                    try {
                        string usergender;
                        cout << "Enter gender (male/female): ";
                        cin >> usergender;

                        if (usergender != "male" && usergender != "female") {
                            throw runtime_error("Error: Invalid gender entered. Please enter 'male' or 'female'.");
                        }

                        gender = usergender;
                        break;
                    }
                    catch (const exception& e) {
                        cin.clear();  // clear input buffer

                        cerr << e.what() << endl;
                    }
                }

                cout << "Enter patient medical history:(emergence > seniorcitizen > youngchild > normal) : ";
                cin.ignore(); // Clear newline character from the buffer
                getline(cin, medicalHistory);
                while (true) {
                    if (medicalHistory == "emergence")
                    {
                        priority = 4;
                        break;
                    }
                    else if (medicalHistory == "seniorcitizen")
                    {
                        priority = 3;
                        break;
                    }
                    else if (medicalHistory == "youngchild")
                    {
                        priority = 2;
                        break;
                    }
                    else if (medicalHistory == "normal")
                    {
                        priority = 1;

                        break;
                    }
                    else {
                        cout << "invalid input :";
                    }
                }
                string choice;
                cout << "Are you sure with all the inputs that you have entered:(yes/no) ";
                cin >> choice;
                if (choice == "yes" || choice == "YES")
                {

                    Patient patient(name, age, weight, gender, medicalHistory, priority);
                    queue.enqueue(patient);
                    InsertRecord(name, age, weight, gender, medicalHistory, priority);
                    break;


                }
                else
                {
                    cout << "Again take all the inputs :";
                }
            }


        }
        else if (option == 2) {
            // Display the record
            queue.displayQueue();
        }
        else if (option == 3) {
            // Search
            int id;
            cout << "Enter patient ID: ";
            cin >> id;

            Patient* patient = queue.searchPatientById(id);
            if (patient) {
                cout << "Patient found: " << patient->name << ", " << patient->age << ", " << patient->weight << ", " << patient->gender << ", " << patient->medicalHistory << ", " << patient->priority << endl;
            }
            else {
                cout << "Patient not found." << endl;
            }
        }
        else if (option == 4) {
            // Update
            int id;
            cout << "Enter patient ID: ";
            cin >> id;

            Patient* patient = queue.searchPatientById(id);
            if (patient) {
                updatePatientInformation(patient);
            }
            else {
                cout << "Patient not found." << endl;
            }
        }
        else if (option == 5) {
          // remove
            int  id;
            cout << "Enter the id of the patient you want to remove: ";
            cin >> id;
            removePatientById(queue, id);
       
        }
        else if (option == 6) {
            // Statistics
            displayStatistics(queue);
        }
        else if (option == 7) {
            // Treat Patient
            queue.treatPatient();
        }
        else if (option == 8) {
            // Display all the record in the database
            cout << "All the data in the data base.\n";
            FetchAllData();
        }
        else if (option == 9) {
            // Delete the record of the client in the database
            string name;
            cout << "Enter the name whose data do you want to delete:\n";
            cin >> name;
            DeleteRecordsByName(name);
        }
        else if (option == 10) {
            // Exit
            cout << "Exiting program.\n";
        }
        else {
            cout << "Invalid option. Please try again.\n";
        }

    } while (option != 10);

    return 0;
}